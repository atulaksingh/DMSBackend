import React from "react";

function IncomeTD() {
  return <div>IncomeTD</div>;
}

export default IncomeTD;
