import React from "react";

function PfUpdate() {
  return (
    <>
      <div>PfUpdate</div>
    </>
  );
}

export default PfUpdate;
